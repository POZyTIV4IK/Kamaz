'use strict'

import { deprecatedIndexFileError } from './deprecatedIndexFileError'

deprecatedIndexFileError(__filename)

console.warn('Warning: ' +
  'The file "mathjs/index.js" is deprecated since v6.0.0. ' +
  'Please use the root "mathjs" instead')

module.exports = require('./lib/entry/mainAny')

export * from './es6/number'

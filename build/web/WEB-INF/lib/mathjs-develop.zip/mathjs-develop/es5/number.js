module.exports = require('../lib/entry/mainNumber')

module.exports = require('../lib/entry/mainAny')

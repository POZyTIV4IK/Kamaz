export * from '../src/entry/mainAny'
